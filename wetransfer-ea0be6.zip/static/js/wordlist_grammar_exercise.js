
function hide_hints() {
  {% for i in range(0, 3) %}
  var x = document.getElementById("hints_{{i}}");
  x.style.display = "none";
  {% endfor %}
}
  {% for i in range(0, 3) %}
  var built_text_{{i}} = []
  $('.print_{{i}}').click(function(){
  	var $this = $(this);
  	$this.prop('disabled', true)
  	$('#built_text_{{i}}').text($('#built_text_{{i}}').text() + ' ' + $this.text());
  	built_text_{{i}}.push($this.text())
  	console.log(built_text_{{i}})
  });
  $('.restart').click(function(){
  	built_text_{{i}} = []
  	var elements = document.getElementsByClassName('print_{{i}}');
  
  	for (var i = 0; i < elements.length; i++) {
  		elements[i].disabled = false;
  	}
  	$('#built_text_{{i}}').text('')
  });
  {% endfor %}
  $('.check').click(function(){
  {% if conjugation %} 
  {% if current_exercise_level == 'easy' %} 
  var x = document.getElementById("vdab_wl_q").value;
  {% else %}
  var x = document.getElementByClassName("vdab_wl_answer").text;
  
  $.ajax({
  	      url: "/{{lang_code}}/exercises/grammar/post_wordlist?type={{current_exercise_type}}&level={{current_exercise_level}}&id={{exercise_id}}&topic={{current_exercise_topic}}",
  	      type: "post",
  	      data: JSON.stringify({'received_answer': x}), //
  						 contentType: 'application/json;charset=UTF-8',
  						 dataType: 'json',
  
  	      success: function(response) {
		  if (response['scores']) {
		  document.querySelector('#score').innerHTML = '<span class = "correct-answer font-weight-bold" style="font-size:1.2rem">Correct! 😊 </span>'
		  } else {
		  document.querySelector('#score').innerHTML = '<span  style="font-size:1.2rem"><span class = "incorrect-answer font-weight-bold">Wrong ☹️</span> Correct answer: ' + "{{correct_answers[0]}}</span>"
		  }
  	      },
  	      error: function(xhr) {
  							console.log('error')
  							console.log(xhr)
  	      }
  	     });
  {% else %}
  hide_hints()
  $.ajax({
  	      url: "/{{lang_code}}/exercises/grammar/post_wordlist?type={{current_exercise_type}}&level={{current_exercise_level}}&id={{exercise_id}}&topic={{current_exercise_topic}}",
  	      type: "post",
  	      data: JSON.stringify({ {% for i in range(0, 3) %}'built_text_{{i}}': built_text_{{i}},{% endfor %} }), //
  						 contentType: 'application/json;charset=UTF-8',
  						 dataType: 'json',
  
  	      success: function(response) {
  							console.log(response['scores'])
							for (var i = 0; i < response['scores'].length; i++) {
							console.log(i)
								corrected_text = ''
								if (response['built_texts'][i].length != '') {
									for (var j = 0; j < response['scores'][i].length; j++) {
										score = response['scores'][i][j]
										console.log(score[2])
										if (score[2] == 1) {
											corrected_text = corrected_text + '<span style = "color:green">' + score[0] + "</span> "
										}
										else {
											corrected_text = corrected_text + '<span style = "color: red">' + score[0] + "</span> "
										}
										
									}
									}
								
								var x = document.getElementById("feedback_" + i);
  							x.style.display = "block"
								if (response['overall_scores'][i] == 1) {
									document.querySelector('#score_' + i).innerHTML = '<span class = "correct-answer">Correct!</span>'
									}
									
								else {
									document.querySelector('#score_' + i).innerHTML = '<span class = "incorrect-answer">Wrong!</span>'
									document.querySelector('#correct_text_' + i).innerHTML = '<strong>Correct answer:</strong> ' + response['random_part'][i]
								}
								document.querySelector('#built_text_' + i).innerHTML = corrected_text
								var x = document.getElementById("puzzle_pieces");
								x.style.visibility = "none"
  							}
  	      },
  	      error: function(xhr) {
  							console.log('error')
  							console.log(xhr)
  	      }
  	     });
		 {% endif %}
  });