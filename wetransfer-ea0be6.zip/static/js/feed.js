
  // Get references to the dom elements
  var scroller = document.querySelector("#scroller");
  var template = document.querySelector('#post_template');
  var loaded = document.querySelector("#loaded");
  var sentinel = document.querySelector('#sentinel');
  // Set a counter to count the items loaded
  var counter = {{texts|length}}
  console.log('counter', counter)
  
  // Function to request new items and render to the dom
  function loadItems() {
  
  $.get("/{{lang_code}}/feed/{{mode_seen + '_' + mode_understood}}/{{current_topic}}/{{level_type}}/{% if current_level >= 0 %}{{current_level}}{% endif %}?start=" + parseInt(counter), function(data) {
   if (counter != 0) {
  	data = $.parseJSON(data)} else {
  	
  
    // Replace the spinner with "No more posts"
    sentinel.innerHTML = "<div class = 'mt-3 mb-3 text-muted'><small>No texts found</small></div>";
  		document.getElementById("text_stats").style.display = 'none';
    return;}
  
   // If empty JSON, exit the function
   if (!data['texts'].length) {
  
    // Replace the spinner with "No more posts"
    sentinel.innerHTML = "<div class = 'mt-3 mb-3 text-muted'><small></small></div>";
    return;
   }
  if (data['texts'].length) {
   // Iterate over the items in the response
   for (var i = 0; i < data['texts'].length; i++) {
  		console.log('i ', i, ' text')
  
    // Clone the HTML template
    let template_clone = template.content.cloneNode(true);
  
    // Query & update the template content
  		template_clone.querySelector("#text_container").setAttribute("text_id", data['text_idxs'][i])
    template_clone.querySelector("#text_number").innerHTML = "Text " + (i + counter + 1) + " <a href = '/{{lang_code}}/texts/" + parseInt(data['text_idxs'][i]) + "'><i class=\"fas fa-angle-double-right\"></i></a>";
  		var diff = data['text_diffs'][i]
  		if (diff % 1 != 0) {
  			diff = Number(diff).toFixed(2)
  		}
    //template_clone.querySelector("#text_diff").innerHTML = 'Level: ' + parseFloat(diff);
    template_clone.querySelector("#text_content").innerHTML = data['texts'][i];
  		
  		if (data['liked_idxs'].includes(data['text_idxs'][i])) {
  		template_clone.querySelector("#like_reaction").className += ' fas'
  		} else {
  		template_clone.querySelector("#like_reaction").className += ' far'
  		}
  		
  		template_clone.querySelector("#exercises_reaction").href = '/{{lang_code}}/exercises/vocab/' + parseInt(data['text_idxs'][i])
  		console.log(data['text_idxs'][i], data['understood_idxs'], data['text_idxs'][i] in data['understood_idxs'] )
  		if (data['understood_idxs'].includes(data['text_idxs'][i] )) {
  		
  		template_clone.querySelector("#understand_reaction").className = 'btn btn-danger understand_text'
  		template_clone.querySelector("#understand_reaction").innerText = 'not ok'
  		} else {
  		template_clone.querySelector("#understand_reaction").className = 'btn btn-light understand_text'
  		template_clone.querySelector("#understand_reaction").innerText = 'ok'
  		}
  		
  
    // Append template to dom
    scroller.appendChild(template_clone);
  
   }
  
    // Increment the counter
    counter += data['texts'].length;
  		console.log('new counter', counter)
  
    // Update the counter in the navbar
    loaded.innerText = `${counter} texts shown`;
  		
  		$(function() {
  		    $('[data-toggle="popover"]').popover({html: true, trigger: 'click', })
  					 
  		    $("body").on('click', '.add', function(event){
  		     var word2add_to_dict = $(this).next().text();
  		     if ($(this).hasClass('dict-word')) {
  						 $(this).removeClass('dict-word');
  						 } else {
  						 $(this).addClass('dict-word');
  						 }
  		   
  		     $.ajax({
  		      url: "/{{lang_code}}/toggle_word2dict",
  		      type: "get",
  		      data: {jsdata: word2add_to_dict}, //
  		      success: function(response) {
  		      },
  		      error: function(xhr) {
  		      }
  		     });
  		    });
  		    $("body").on('click', '.grammar-add', function(event){
  		     var grammar_to_add_to_dict = $(this).next().text();
  		     $.ajax({
  		      url: "/{{lang_code}}/toggle_grammar2dict",
  		      type: "get",
  		      data: {jsdata: grammar_to_add_to_dict}, //
  		      success: function(response) {
  		      },
  		      error: function(xhr) {
  		      }
  		     });
  		    });
  		   });
  	$("html").on("mouseup", function (e) {
   var l = $(e.target);
   if (l[0].className.indexOf("popover") == -1) {
    $(".popover").each(function () {
     $(this).popover("hide");
    });
   }
  });
   }
   }
  )}
  
  
  
  // Create a new IntersectionObserver instance
  var intersectionObserver = new IntersectionObserver(entries => {
  
  // Uncomment below to see the entry.intersectionRatio when
  // the sentinel comes into view
  
  // entries.forEach(entry => {
  // console.log(entry.intersectionRatio);
  // })
  
  // If intersectionRatio is 0, the sentinel is out of view
  // and we don't need to do anything. Exit the function
  if (entries[0].intersectionRatio <= 0) {
   return;
  }
  
  // Call the loadItems function
  loadItems();
  rebind_controls();
  
  });
  
  // Instruct the IntersectionObserver to watch the sentinel
  intersectionObserver.observe(sentinel);
  $(function() {
     $('[data-toggle="popover"]').popover({html: true, trigger: 'click', })
  			 
     $("body").on('click', '.add', function(event){
      var word2add_to_dict = $(this).next().text();
      if ($(this).hasClass('dict-word')) {
  				 $(this).removeClass('dict-word');
  				 } else {
  				 $(this).addClass('dict-word');
  				 }
    
      $.ajax({
       url: "/{{lang_code}}/toggle_word2dict",
       type: "get",
       data: {jsdata: word2add_to_dict}, //
       success: function(response) {
       },
       error: function(xhr) {
       }
      });
     });
     $("body").on('click', '.grammar-add', function(event){
      var grammar_to_add_to_dict = $(this).next().text();
      $.ajax({
       url: "/{{lang_code}}/toggle_grammar2dict",
       type: "get",
       data: {jsdata: grammar_to_add_to_dict}, //
       success: function(response) {
       },
       error: function(xhr) {
       }
      });
     });
    });
  $("html").on("mouseup", function (e) {
  var l = $(e.target);
  if (l[0].className.indexOf("popover") == -1) {
   $(".popover").each(function () {
    $(this).popover("hide");
   });
  }
  });
  rebind_controls = function(){
     
    
     $("button.understand_text").unbind().click(function(){
      // "understand" button usage
    
      //change color to green
      if( this.style.backgroundColor == '#3CB371' ){
       this.style.backgroundColor = ''
      }else{
       this.style.backgroundColor = '#3CB371'
      }
    
      text_level_wrapper = $(this).parent().parent()
      // ajax request with text/wordgram_id user_id from cookies
      $.ajax({url:"/{{lang_code}}/feed/{{mode_seen + '_' + mode_understood}}/{{current_topic}}/{{level_type}}/{% if current_level >= 0 %}{{current_level}}{% endif%}",
       data:{
        text_id: text_level_wrapper.attr('text_id'),
        event : "button.understand_text click"
    
       },
       type:'POST'
    
      })
    
     });
     
    
     $("button.like_text").unbind().click(function(){
      // "understand" button usage
      //change color to green
      if( $(this).css("color") == 'red' ){
  					$(this).css('color', '')
      }else{
  					$(this).find($(".far")).removeClass('far').addClass('fas');
       $(this).css("color", 'red');
      }
    
      text_level_wrapper = $(this).parent().parent()
      // ajax request with text/wordgram_id user_id from cookies
      $.ajax({url:"/{{lang_code}}/feed/{{mode_seen + '_' + mode_understood}}/{{current_topic}}/{{level_type}}/{% if current_level >= 0 %}{{current_level}}{% endif%}",
       data:{
        text_id: text_level_wrapper.attr('text_id'),
        event : "button.like_text click"
    
       },
       type:'POST'
    
      })
    
     });
    };
    
    $(document).ready(function(){
    
     rebind_controls();
    
    })
  update_level_type = function(){
  		 $("a[href*='/{{level_type}}/").each(function()
  { 
  if ('{{level_type}}' == 'manual_level') {
  this.href = this.href.replace(/{{level_type}}/, 
   "calculated_level");}
  else { this.href = this.href.replace(/{{level_type}}/, 
   "manual_level");}
  } );
    $.ajax({
       url: "/{{lang_code}}/feed/",
       type: "post",
       data: {'level_type':1}, //
       success: function(response) {
       },
       error: function(xhr) {
       }
      });
    };
{% if guide %}
document.addEventListener("DOMContentLoaded", function() { 
  introJs().setOption('showProgress', true).start();
  }); 
{% endif %}