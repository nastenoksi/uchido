
  $(function() {
     $('[data-toggle="popover"]').popover({html: true, trigger: 'click', })
  			 
     $("body").on('click', '.add', function(event){
      var word_to_add_to_dict = $(this).next().text();
      if ($(this).hasClass('dict-word')) {
  				 $(this).removeClass('dict-word');
  				 } else {
  				 $(this).addClass('dict-word');
  				 }
    
      $.ajax({
       url: "/toggle_word2dict",
       type: "get",
       data: {jsdata: word_to_add_to_dict}, //
       success: function(response) {
       },
       error: function(xhr) {
       }
      });
     });
     $("body").on('click', '.grammar-add', function(event){
      var grammar_to_add_to_dict = $(this).next().text();
      $.ajax({
       url: "/toggle_grammar2dict",
       type: "get",
       data: {jsdata: grammar_to_add_to_dict}, //
       success: function(response) {
       },
       error: function(xhr) {
       }
      });
     });
    });
  $("html").on("mouseup", function (e) {
  var l = $(e.target);
  if (l[0].className.indexOf("popover") == -1) {
   $(".popover").each(function () {
    $(this).popover("hide");
   });
  }
  });
  rebind_controls = function(){
     
    
     $("button.understand_grammar").unbind().click(function(){
      // "understand" button usage
    
      //change color to green
      if( this.style.backgroundColor == '#3CB371' ){
       this.style.backgroundColor = ''
      }else{
       this.style.backgroundColor = '#3CB371'
      }
    
      // ajax request with text/grammargram_id user_id from cookies
      $.ajax({url:"{{lang_code}}/grammars/{{grammar_key}}",
       data:{
        event : "button.understand_grammar click"
    
       },
       type:'POST'
    
      })
    
     });
    };
    
    $(document).ready(function(){
    
     rebind_controls();
    
    })
  $(document).ready(function() {
     $(".add_grammar").click(function(){
      $(this).hide();
      $.ajax({
       url: "/add_grammar2dict",
       type: "get",
       data: {jsdata: "{{grammar_key}}"}, //
       success: function(response) {
       },
       error: function(xhr) {
       }
      });
     });
    });