
$(function() {
            $("body").on('click', '.add', function(event) {
                var word_to_add_to_dict = $(this).next().text();
                if ($(this).hasClass('dict-word')) {
                    $(this).removeClass('dict-word');
                } else {
                    $(this).addClass('dict-word');
                }

                $.ajax({
                    url: "/{{lang_code}}/toggle_word2dict",
                    type: "get",
                    data: {
                        jsdata: word_to_add_to_dict
                    },
                    success: function(response) {},
                    error: function(xhr) {}
                });
            });
            $("body").on('click', '.grammar-add', function(event) {
                var grammar_to_add_to_dict = $(this).next().text();
                $.ajax({
                    url: "/{{lang_code}}/toggle_grammar2dict",
                    type: "get",
                    data: {
                        jsdata: grammar_to_add_to_dict
                    }, //
                    success: function(response) {},
                    error: function(xhr) {}
                });
            });
            $("html").on("mouseup", function(e) {
                var l = $(e.target);
                if (l[0].className.indexOf("popover") == -1) {
                    $(".popover").each(function() {
                        $(this).popover("hide");
                    });
                }
            });
            rebind_controls = function() {
                $('[data-toggle="popover"]').popover({
                    html: true,
                    trigger: 'click',
                })


                $("button.understand_word").unbind().click(function() {
                    if (this.style.backgroundColor == '#3CB371') {
                        this.style.backgroundColor = ''
                    } else {
                        this.style.backgroundColor = '#3CB371'
                    }

                    $.ajax({
                        url: "/{{lang_code}}/words/{{word_key[0]}}_{{word_key[1]}}",
                        data: {
                            event: "button.understand_word click"

                        },
                        type: 'POST'

                    })

                });



                $("button.learn_word").unbind().click(function() {
                    $.ajax({
                        url: "/{{lang_code}}/learn_word/{{word_key[0]}}_{{word_key[1]}}",
                        data: {
                            event: "button.learn_word click"

                        },
                        type: 'POST'

                    })

                });

                $("i.upvote_sentence").unbind().click(function() {
                    $.ajax({
                        url: "/{{lang_code}}/words/{{word_key[0]}}_{{word_key[1]}}",
                        data: {
                            event: "i.upvote_sentence click",
                            sentence_id: $(this).attr('sentence_idx')

                        },
                        type: 'POST'

                    })

                });

                $("i.downvote_sentence").unbind().click(function() {
                    // "understand" button usage
                    // ajax request with text/wordgram_id user_id from cookies
                    $.ajax({
                        url: "/{{lang_code}}/words/{{word_key[0]}}_{{word_key[1]}}",
                        data: {
                            event: "i.downvote_sentence click",
                            sentence_id: $(this).attr('sentence_idx')

                        },
                        type: 'POST'

                    })

                });
            };

            $(document).ready(function() {

                rebind_controls();

            })

            function search_word() {

                $.ajax({
                    url: "/{{lang_code}}/toggle_word2dict",
                    type: "get",
                    data: {
                        jsdata: word_to_add_to_dict
                    }, //
                    success: function(response) {},
                    error: function(xhr) {}
                });
            }

            $(document).ready(function() {
                $(".add_word").click(function() {
                    $(this).hide();
                    $.ajax({
                        url: "/{{lang_code}}/add_word2dict",
                        type: "get",
                        data: {
                            jsdata: "{{word_key[0]}}_{{word_key[1]}}"
                        }, //
                        success: function(response) {},
                        error: function(xhr) {}
                    });
                });
            });

            function show_edit_translation() {
                var x = document.getElementById("edit_translation_field");
                x.style.display = "block";
                var x = document.getElementById("edit_translation_button");
                x.style.display = "none";
            }
            $(document).ready(function() {
                $(".edit_translation").click(function() {
                    $(this).hide();
                    var x = document.getElementById("edit_translation_field");
                    x.style.display = "none";
                    console.log($("#edit_translation_input").val())
                    $.ajax({
                        url: "/{{lang_code}}/edit_translation",
                        type: "get",
                        data: {
                            jsdata: "{{word_key[0]}}_{{word_key[1]}}",
                            translation: $("#edit_translation_input").val()
                        }, //
                        success: function(response) {},
                        error: function(xhr) {}
                    });
                });
            });

            function show_edit_pos() {
                var x = document.getElementById("edit_pos_field");
                x.style.display = "block";
                var x = document.getElementById("edit_pos_button");
                x.style.display = "none";
            }
            $(document).ready(function() {
                $(".edit_pos").click(function() {
                    $(this).hide();
                    var x = document.getElementById("edit_pos_field");
                    x.style.display = "none";
                    console.log($("#edit_pos_input").children("option:selected").val())
                    $.ajax({
                        url: "/{{lang_code}}/edit_pos",
                        type: "get",
                        data: {
                            jsdata: "{{word_key[0]}}_{{word_key[1]}}",
                            pos: $("#edit_pos_input").children("option:selected").val()
                        }, //
                        success: function(response) {},
                        error: function(xhr) {}
                    });
                });
            });
            $(document).ready(function() {
                var messages = "{{ get_flashed_messages() }}";

                if (typeof messages != 'undefined' && messages != '[]') {
                    $("#exampleModal").modal();
                };
            });
            // Get references to the dom elements
            var scroller = document.querySelector("#scroller");
            var template = document.querySelector('#post_template');
            var loaded = document.querySelector("#loaded");
            var sentinel = document.querySelector('#sentinel');
            // Set a counter to count the items loaded
            var counter = {
                {
                    used_sentences | length
                }
            }
            console.log('counter', counter)

            // Function to request new items and render to the dom
            function loadItems() {

                $.get("/{{lang_code}}/words/{{word_key[0]}}_{{word_key[1]}}/?start=" + parseInt(counter), function(data) {
                    if (counter != 0) {
                        data = $.parseJSON(data)
                    } else {


                        // Replace the spinner with "No more posts"
                        sentinel.innerHTML = "<div class = 'mt-3 mb-3 text-muted'><small>No examples found</small></div>";
                        document.getElementById("text_stats").style.display = 'none';
                        return;
                    }

                    // If empty JSON, exit the function
                    if (!data['used_sentences'].length) {

                        // Replace the spinner with "No more posts"
                        sentinel.innerHTML = "<div class = 'mt-3 mb-3 text-muted'><small></small></div>";
                        return;
                    }
                    if (data['used_sentences'].length) {
                        // Iterate over the items in the response
                        for (var i = 0; i < data['used_sentences'].length; i++) {
                            console.log('i ', i, ' text')
                            counter += 1;

                            // Clone the HTML template
                            let template_clone = template.content.cloneNode(true);

                            // Query & update the template content
                            template_clone.querySelector("#title").innerHTML = "<span class = 'font-weight-bold'>" + counter + "</span> <span class = 'text-uppercase small text-muted'><a href = '/{{lang_code}}/texts/" + data['idxs'][i][0] + "?abs=True'>Text " + (data['idxs'][i][0] + 1) + "</a> | Sentence " + (data['idxs'][i][1] + 1) + "</span>";
                            template_clone.querySelector("#content").innerHTML = data['used_sentences'][i] + "<p class = 'small text-muted text-right'><a href = '#'><i class='far fa-thumbs-up upvote_sentence' sentence_idx = '(" + data['idxs'][i][0] + ', ' + data['idxs'][i][1] + ")'></i>" + data['upvotes'][i] + "</a> <a href = '#'><i class='far fa-thumbs-down downvote_sentence' sentence_idx = '(" + data['idxs'][i][0] + ', ' + data['idxs'][i][1] + ")'</i>" + data['downvotes'][i] + "</a></p>";

                            // Append template to dom
                            scroller.appendChild(template_clone);
                            console.log('i + counter + 1 % 3 ', (i + 1) % 3)
                            if ((i + 1) % 3 == 0) {
                                var para = document.createElement("div");
                                para.className = 'mt-2 mb-2 w-100'
                                scroller.appendChild(para);

                            }
                        }

                        // Increment the counter
                        counter += data['used_sentences'].length;
                        console.log('new counter', counter)

                        // Update the counter in the navbar
                        loaded.innerText = `${counter} examples shown`;

                        $(function() {
                            $('[data-toggle="popover"]').popover({
                                html: true,
                                trigger: 'click',
                            })

                            $("body").on('click', '.add', function(event) {
                                var word_to_add_to_dict = $(this).next().text();
                                if ($(this).hasClass('dict-word')) {
                                    $(this).removeClass('dict-word');
                                } else {
                                    $(this).addClass('dict-word');
                                }

                                $.ajax({
                                    url: "/{{lang_code}}/toggle_word2dict",
                                    type: "get",
                                    data: {
                                        jsdata: word_to_add_to_dict
                                    }, //
                                    success: function(response) {},
                                    error: function(xhr) {}
                                });
                            });
                            $("body").on('click', '.grammar-add', function(event) {
                                var grammar_to_add_to_dict = $(this).next().text();
                                $.ajax({
                                    url: "/{{lang_code}}/toggle_grammar2dict",
                                    type: "get",
                                    data: {
                                        jsdata: grammar_to_add_to_dict
                                    }, //
                                    success: function(response) {},
                                    error: function(xhr) {}
                                });
                            });
                        });
                        $("html").on("mouseup", function(e) {
                            var l = $(e.target);
                            if (l[0].className.indexOf("popover") == -1) {
                                $(".popover").each(function() {
                                    $(this).popover("hide");
                                });
                            }
                        });
                    }
                })
            }


            var intersectionObserver = new IntersectionObserver(entries => {
                if (entries[0].intersectionRatio <= 0) {
                    return;
                }

                loadItems();
                rebind_controls();

            });

            intersectionObserver.observe(sentinel);
{% if guide %}
document.addEventListener("DOMContentLoaded", function() { 
  introJs().setOption('showProgress', true).start();
  }); 
{% endif %}