
  $(function() {
        $('[data-toggle="popover"]').popover({html: true, trigger: 'click', })
  			 
        $("body").on('click', '.add', function(event){
          var word_to_add_to_dict = $(this).next().paragraph();
          if ($(this).hasClass('dict-word')) {
  				 $(this).removeClass('dict-word');
  				 } else {
  				 $(this).addClass('dict-word');
  				 }
      
          $.ajax({
            url: "/{{lang_code}}/toggle_word2dict",
            type: "get",
            data: {jsdata: word_to_add_to_dict}, //
            success: function(response) {
            },
            error: function(xhr) {
            }
          });
        });
        $("body").on('click', '.grammar-add', function(event){
          var grammar_to_add_to_dict = $(this).next().paragraph();
          $.ajax({
            url: "/{{lang_code}}/toggle_grammar2dict",
            type: "get",
            data: {jsdata: grammar_to_add_to_dict}, //
            success: function(response) {
            },
            error: function(xhr) {
            }
          });
        });
      });
  $("html").on("mouseup", function (e) {
   var l = $(e.target);
   if (l[0].className.indexOf("popover") == -1) {
     $(".popover").each(function () {
       $(this).popover("hide");
     });
   }
  });
  update_level_type = function(){
  		 $("a[href*='/{{current_level_type}}/").each(function()
  { 
    if ('{{current_level_type}}' == 'manual_level') {
  this.href = this.href.replace(/{{current_level_type}}/, 
     "calculated_level");}
  else { this.href = this.href.replace(/{{current_level_type}}/, 
     "manual_level");}
  } );
      $.ajax({
            url: "/{{lang_code}}/paragraphs/{{current_topic}}/{{current_level_type}}/{{current_level}}/{{current_text_id}}_{{current_paragraph_id}}",
            type: "post",
            data: {'level_type':1}, //
            success: function(response) {
            },
            error: function(xhr) {
            }
          });
      };
  rebind_controls = function(){
  
  
        $('[data-toggle="popover"]').popover({html: true, trigger: 'click', })
        
      
        $("button.understand_paragraph").unbind().click(function(){
          // "understand" button usage
      
      if( $(this).css("color") == 'red' ){
  					$(this).css('color', '')
      }else{
  					$(this).find($(".far")).removeClass('far').addClass('fas');
       $(this).css("color", 'red');
      }
          // ajax request with paragraph/wordgram_id user_id from cookies
          $.ajax({url:"/{{lang_code}}/paragraphs/{{current_topic}}/{{current_level_type}}/{{current_level}}/{{current_abs_text_id}}_{{current_paragraph_id}}",
            data:{
              paragraph_id: {{current_paragraph_id}},
              event : "button.understand_paragraph click"
      
            },
            type:'POST'
      
          })
      
        });
      };
      
      $(document).ready(function(){
      
        rebind_controls();
      
      })
{% if guide %}
document.addEventListener("DOMContentLoaded", function() { 
  introJs().setOption('showProgress', true).start();
  }); 
{% endif %}