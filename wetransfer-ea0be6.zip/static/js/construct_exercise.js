
function hide_hints() {
  var x = document.getElementById("hints_1");
  x.style.display = "none";
  var x = document.getElementById("hints_2");
  x.style.display = "none";
}
  var built_text = []
  $('.print').click(function(){
  	var $this = $(this);
  	$this.prop('disabled', true)
  	$('#built_text').text($('#built_text').text() + ' ' + $this.text());
  	built_text.push($this.text())
  	console.log(built_text)
  });
  $('.restart').click(function(){
  	built_text = []
  	var elements = document.getElementsByClassName('print');
  
  	for (var i = 0; i < elements.length; i++) {
  		elements[i].disabled = false;
  	}
  	$('#built_text').text('')
  });
  
  $('.check').click(function(){
  $.ajax({
  	      url: "/{{lang_code}}/exercises/grammar/construct/{{name}}?r={{random_index}}",
  	      type: "post",
  	      data: JSON.stringify({'built_text': built_text}), //
  						 contentType: 'application/json;charset=UTF-8',
  						 dataType: 'json',
  
  	      success: function(response) {
  							console.log(response['scores'])
  							corrected_text = ''
  							for (var i = 0; i < response['scores'].length; i++) {
  								score = response['scores'][i]
  								if (score[2] == 1) {
  									corrected_text = corrected_text + '<span class = "correct-answer">' + score[0] + "</span> "
  								}
  								else {
  									corrected_text = corrected_text + '<span class = "incorrect-answer">' + score[0] + "</span> "
  								}
  								
  							}
  							
  							var x = document.getElementById("feedback");
  							x.style.display = "block"
  							if (response['overall_score'] == 1) {
  								document.querySelector('#score').innerHTML = '<span class = "correct-answer">Correct!</span>'
  								}
  							 else {
  							 	document.querySelector('#score').innerHTML = '<span class = "incorrect-answer">Wrong!</span>'
								if (response['reverse']) {
									answer = response['random_part'] + ' ' + response['fixed_part']
								} else {
									answer = response['fixed_part'] + ' ' + response['random_part']
								}
								document.querySelector('#correct_text').innerHTML = "<span class = 'font-weight-bold'>Correct answer:</span> " + answer + response['eos']
  							 }
							if (corrected_text == '') {
								corrected_text = response['built_text']
							}
  							document.querySelector('#built_text').innerHTML = corrected_text
							console.log(corrected_text)
  							
  							var x = document.getElementById("puzzle_pieces");
  							x.style.visibility = "none"
  							console.log(x.style.visibility)
  							
  	      },
  	      error: function(xhr) {
  							console.log('error')
  							console.log(xhr)
  	      }
  	     });
  });