

function show_edit_translation(){
	  var x = document.getElementById("edit_translation_field");
	  x.style.display = "block";
	  var x = document.getElementById("edit_translation_button");
	  x.style.display = "none";
}
  $(document).ready(function() {
     $(".edit_translation").click(function(){
      $(this).hide();
	  var x = document.getElementById("edit_translation_field");
	  x.style.display = "none";
	  console.log($("#edit_translation_input").val())
      $.ajax({
       url: "/{{lang_code}}/edit_translation",
       type: "get",
       data: {jsdata: "{{word}}", translation: $("#edit_translation_input").val()}, //
       success: function(response) {
       },
       error: function(xhr) {
       }
      });
     });
    });